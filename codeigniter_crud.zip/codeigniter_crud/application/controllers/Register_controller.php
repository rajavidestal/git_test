<?php
class Register_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model('Register_model'); ///load model
        // File upload path 
        $this->uploadPath = 'assets/image/';
    }

    public function savedata()
    {

        $config['upload_path']   = $this->uploadPath;
        $config['allowed_types'] = 'jpg|jpeg|png|JPG|JPEG|PNG';
        // Load and initialize upload library 
        $this->load->library('upload', $config);
        // Upload file to server 
        if ($this->upload->do_upload('image')) {
            $uploadData = $this->upload->data();
            $uploadedImage = $uploadData['file_name'];
            $source_path = $this->uploadPath . $uploadedImage;

            $data = array(
                'Name' => $this->input->post('name'),
                'Gender' => $this->input->post('gender'),
                'Birth_Date' => $this->input->post('dob'),
                'Blood_Group' => $this->input->post('blood_group'),
                'Maritial_status' => $this->input->post('Maritial_status'),
                'Address' => $this->input->post('address'),
                'Country' => $this->input->post('country'),
                'State' => $this->input->post('state'),
                'City' => $this->input->post('city'),
                'Pincode' => $this->input->post('pincode'),
                'Mobile_No' => $this->input->post('mobile'),
                'Email_id' => $this->input->post('email'),
                'Aadhar_no' => $this->input->post('aadhar'),
                'Photo' => $source_path,
                'flag' => '1'
            );

            $res = $this->Register_model->insert($data);

            echo json_encode($res);
        }
    }

    function retrieve()
    {
        $data['record'] = $this->Register_model->fetchtable();
        $this->load->view('a', $data);
    }

    public function removeUserById()
    {
        $active = array(
            'flag' => '0',
            'id' => $this->input->post('id'),
        );
        $record = $this->Register_model->is_active($active);
        echo json_encode($record);
    }


    public function updateAjax()
    {
        $id = $this->input->post('id');
        $data['userId'] = $this->Register_model->getUserById($id);
        $data['countries'] = $this->Register_model->fetch_country();
        $data['states'] = $this->Register_model->fetchUserState($data['countries']);
        $data['cities'] = $this->Register_model->fetchUserCity($data['states']);
        $resp = $this->load->view('edit', $data);
        echo json_encode($resp);
    }

    // UPDATE
    public function update()
    {

        if (!empty($_FILES['image']['name'])) {
            // echo 'image';
            $config['upload_path']   = $this->uploadPath;
            $config['allowed_types'] = 'jpg|jpeg|png|JPG|JPEG|PNG';
            // Load and initialize upload library 
            $this->load->library('upload', $config);
            // Upload file to server 
            if ($this->upload->do_upload('image')) {
                $uploadData = $this->upload->data();
                $uploadedImage = $uploadData['file_name'];
                // $org_image_size = $uploadData['image_width'].'x'.$uploadData['image_height'];                     
                $source_path = $this->uploadPath . $uploadedImage;
                // echo $source_path;
                $id = $this->input->post('id');
                // print_r($id);
                $data = array(

                    'Name' => $this->input->post('name'),
                    'Gender' => $this->input->post('gender'),
                    'Birth_Date' => $this->input->post('dob'),
                    'Blood_Group' => $this->input->post('blood_group'),
                    'Maritial_status' => $this->input->post('Maritial_status'),
                    'Address' => $this->input->post('address'),
                    'Country' => $this->input->post('country'),
                    'State' => $this->input->post('state'),
                    'City' => $this->input->post('city'),
                    'Pincode' => $this->input->post('pincode'),
                    'Mobile_No' => $this->input->post('mobile'),
                    'Email_id' => $this->input->post('email'),
                    'Aadhar_no' => $this->input->post('aadhar'),
                    'Photo' => $source_path,
                    'id' => $this->input->post('id'),
                );

                $updateres = $this->Register_model->update_records($data);
                echo json_encode($updateres);
            }
        } else {
            $data = array(
                'Name' => $this->input->post('name'),
                'Gender' => $this->input->post('gender'),
                'Birth_Date' => $this->input->post('dob'),
                'Blood_Group' => $this->input->post('blood_group'),
                'Maritial_status' => $this->input->post('Maritial_status'),
                'Address' => $this->input->post('address'),
                'Country' => $this->input->post('country'),
                'State' => $this->input->post('state'),
                'City' => $this->input->post('city'),
                'Pincode' => $this->input->post('pincode'),
                'Mobile_No' => $this->input->post('mobile'),
                'Email_id' => $this->input->post('email'),
                'Aadhar_no' => $this->input->post('aadhar'),
                'id' => $this->input->post('id'),

            );

            $updateres = $this->Register_model->update_records($data);
            echo json_encode($updateres);
        }
    }
    function index()
    {
        $data['countries'] = $this->Register_model->fetch_country();
        $this->load->view('registration_view', $data);
    }
    function fetch_state()
    {
        $country_id = $this->input->post('country_id');
        $states = $this->Register_model->fetch_state($country_id);
        echo json_encode($states);
    }

    function fetch_city()
    {
        $state_id = $this->input->post('state_id');
        $cities = $this->Register_model->fetch_city($state_id);
        echo json_encode($cities);
    }


    public function process()
    {
        $thumb_msg = $status = $status_msg = $thumbnail = $org_image_size = $thumb_image_size = '';
        $data = array();

        // If the file upload form submitted 

        if (!empty($_FILES['image']['name'])) {
            $idp  = "assets/image";
            if (!is_dir($idp)) {
                mkdir($idp, 0777, TRUE);
            }
            // File upload config 
            $config['upload_path']   = $this->uploadPath;
            $config['allowed_types'] = 'jpg|jpeg|png|JPG|JPEG|PNG';

            // Load and initialize upload library 
            $this->load->library('upload', $config);

            // Upload file to server 
            if ($this->upload->do_upload('image')) {
                $uploadData = $this->upload->data();
                $uploadedImage = $uploadData['file_name'];
                $org_image_size = $uploadData['image_width'] . 'x' . $uploadData['image_height'];

                $source_path = $this->uploadPath . $uploadedImage;
                $idp1  = "assets/image/thumbnail";
                if (!is_dir($idp1)) {
                    mkdir($idp1, 0777, TRUE);
                }
                $thumb_path = $this->uploadPath . 'thumbnail/';

                // Image resize config 

                $config['source_image']     = $source_path;
                $config['new_image']         = $thumb_path;
                $config['width']            = 75;
                $config['height']           = 75;

                // Load and initialize image_lib library 
                $this->load->library('image_lib', $config);

                // Resize image and create thumbnail 
                if ($this->image_lib->resize()) {
                    $thumbnail = $thumb_path . $uploadedImage;
                    $thumb_image_size = '75 x 75';
                    $thumb_msg = '<br/>Thumbnail created!';
                } else {
                    $thumb_msg = '<br/>' . $this->image_lib->display_errors();
                }

                $status = 'success';
                $status_msg = 'Image has been uploaded successfully.' . $thumb_msg;
            } else {
                $status = 'error';
                $status_msg = 'The image upload has failed!<br/>' . $this->upload->display_errors('', '');
            }
        } else {
            $status = 'error';
            $status_msg = 'Please select a image file to upload.';
            $thumbnail = 'does image is inserted';
        }
        // if($this->input->post('submit')){ 
        $this->savedata($thumbnail);
        // } 

        // File upload status 
        $data['status'] = $status;
        $data['status_msg'] = $status_msg;
        $data['thumbnail'] = $thumbnail;
        $data['org_image_size'] = $org_image_size;
        $data['thumb_image_size'] = $thumb_image_size;
        return $thumbnail;
        // Load form view and pass upload status 

    }
}
