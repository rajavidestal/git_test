<?php
class Register_model extends CI_Model
{

    function fetch_country()
    {
        $this->db->order_by("country_name", "ASC");
        $query = $this->db->get("countries");
        return $query->result_array();
    }
    function fetchUserState()
    {
        $this->db->order_by("state_name", "ASC");
        $query = $this->db->get("states");
        return $query->result_array();
    }
    function fetchUserCity()
    {
        $this->db->order_by("city_name", "ASC");
        $query = $this->db->get("cities");
        return $query->result_array();
    }
    function fetch_state($country_id)
    {
        $sql = "SELECT * from states where country_id=? order by state_name asc";
        $query = $this->db->query($sql, array($country_id));
        $result = $query->result_array();
        return $result;
    }
    function fetch_city($state_id)
    {
        $sql = "SELECT * from cities where state_id=? order by city_name asc";
        $query = $this->db->query($sql, array($state_id));
        $result = $query->result_array();
        return $result;
    }
    function fetchtable()
    {
        $this->db->select("id, Name, Gender, Blood_Group, Birth_Date, Maritial_status, Address, countries.country_name, states.state_name, cities.city_name, Pincode, Mobile_No,Email_id, Aadhar_no, Photo");
        $this->db->from("user_reg");
        $this->db->join('countries', 'user_reg.Country = countries.country_id');
        $this->db->join('states', ' user_reg.State = states.state_id');
        $this->db->join('cities', 'user_reg.City = cities.city_id');
        $this->db->where('flag', '1');
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    function get_aadhar($aadhar)
    {

        $sql = "SELECT Aadhar_no from user_reg where Aadhar_no=? limit 1";
        $result = $this->db->query($sql, array($aadhar));

        if ($result->num_rows() == 1) {
            return false;
        } else {
            return True;
        }
    }

    public function getUserById($id)
    {
        $sql = "Select * from user_reg where id=?";
        $query = $this->db->query($sql, array($id));
        $result = $query->result();
        return $result;
    }
    /*Insert*/
    public function insert($data)
    {
        $sql = "CALL practice_1('" . json_encode($data, JSON_FORCE_OBJECT) . "')";
        $query = $this->db->query($sql);

        return $query->result();
    }

    /*Update*/
    function update_records($data)
    {
        $stmt = "CALL registration_check('U',' " . json_encode($data, JSON_FORCE_OBJECT) . "')";

        $query = $this->db->query($stmt);
        return $query;
    }

    public function is_active($active)
    {
        $query = "CALL registration_check('D',' " . json_encode($active, JSON_FORCE_OBJECT) . "')";
        $result = $this->db->query($query);
        return $result;
    }
}
