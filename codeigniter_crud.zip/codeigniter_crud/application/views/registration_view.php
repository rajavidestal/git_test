<!DOCTYPE html>

<head>

    <title>User Registration </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Sweet Alert Links-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" integrity="sha512-f8gN/IhfI+0E9Fc/LKtjVq4ywfhYAVeMGKsECzDUHcFJ5teVwvKTqizm+5a84FINhfrgdvjX8hEJbem2io1iTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!--Bootstrap links-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.0/css/bootstrap.min.css">

    <!-- jQuery Links-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!--Inputmasking links-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.min.js"></script>


</head>
<style>
    /* ****************************************************CSS********************************************************  */
    form {
        width: 600px;
        margin: auto;
        border: 2px solid;
        box-shadow: 10px 10px 5px lightgray;

        text-align: center;
        /* background-color:#97BC62FF; */
        background-image: linear-gradient(to bottom, #b6fbff, #83a4d4);
    }


    .submit {
        border-radius: 8px;
        background-color: lightblue;
        font-size: 20px;
        border: 3px;
        color: black;
        margin: auto;
        align-items: center;
        padding: 7px;
        text-align: center;

    }

    .submit:hover {
        background-color: navy;
        color: whitesmoke;
        font-weight: bold;

    }

    h2 {
        text-shadow: 2px 2px 4px gray;
        font-size: 25px;
        text-align: center;
        background-image: linear-gradient(to right, #00b4db, #0083b0);
        height: 30px;
        color: black;
    }

    .personal {

        padding-bottom: 7px;
    }

    .add {

        padding-bottom: 7px;
    }

    .contact {

        padding-bottom: 7px;
    }

    #output {
        width: 25%;
        height: 30%;
    }

    #country-dropdown {
        width: 100%;
        height: 50%;
    }

    #city {
        width: 100%;
        height: 50%;
        align-items: center
    }

    #city-dropdown {
        width: 100%;
        height: 50%;
        align-items: right;
    }

    .card-body {
        display: flex;
        justify-content: space-around;
    }

    .error {
        color: red;
    }

    .hidden {
        visibility: hidden;
    }
</style>

<body>
    <!-- *****************************************************HTML******************************************************* -->
    <form id="form" name="form" enctype='multipart/form-data'>
        <h5 style="color:red;" id="error"></h5>
        <h1 style="text-align:center; font-size: 30px;"><u>User Registration form</u></h1>
        <!--Personal Details-->
        <h2>Personal Details</h2>
        <div class="personal">
            <p>Name:<input type="text" class="name" id="name" name="name" autofocus placeholder="Enter Your Name" maxlength="30"></p>
            <div class="error" id="nameErr"></div>
            <p>Gender: &nbsp;<input type="radio" name="gender" id="male" value="male">Male &nbsp;
                <input type="radio" name="gender" id="female" value="female">Female &nbsp;
                <input type="radio" name="gender" id="other" value="other">Other
            <p>
            <div class="error" id="genderErr"></div>
            Birth Date: <input type="date" name="dob" id="dob" class="dob" min="1930-01-01" max="2017-12-31">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            Blood Group: <select type="text" id="blood_group" name="blood_group" class="blood_group" placeholder="Select Blood Group">
                <option hidden value="0">Select</option>
                <option>A +ve</option>
                <option>A -ve</option>
                <option>B +ve</option>
                <option>B -ve</option>
                <option>AB +ve</option>
                <option>AB -ve</option>
                <option>O +ve</option>
                <option>O -ve</option>
            </select></br>
            <div class="error" id="blooderr" style="float:right; margin-right: 80px;"></div> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="error" id="dobErr" style="float:left; margin-left: 80px;"></div>
            <p>Maritial Status: &nbsp;<input type="radio" id="Single" name="Maritial_status" value="Single">Single &nbsp;
                <input type="radio" id="Married" name="Maritial_status" value="Married">Married &nbsp;
                <input type="radio" id="Divorced" name="Maritial_status" value="Divorced">Divorced
            </p>
            <div class="error" id="statusErr"></div>
            <!--Address-->
            <h2>Address</h2>
            <div class="add">
                <p>Address : <input rows="2" columns="5" type="text" id="address" name="address" class="address" onchange="check_add()" maxlength="100" placeholder="Enter your Address"></p>
                <div class="error" id="addressErr"></div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="country">Country</label>
                        <select class="form-control" id="country-dropdown" name="country">
                            <option value="" selected disabled hidden>Select Country</option>
                            <?php
                            foreach ($countries as $row) {
                                echo '<option value=" ' . $row['country_id'] . '">' . $row['country_name'] . '</option>';
                            }
                            ?>
                        </select>
                        <div class="error" id="countryErr"></div>
                    </div>

                    <div class="form-group">
                        <label for="state">State</label>
                        <select class="form-control" id="state-dropdown" name="state" value="$result">
                            <option value="" selected disabled hidden>Select State</option>
                        </select>
                        <div class="error" id="stateErr"></div>
                    </div>

                    <div class="form-group">
                        <label for="city">City</label>
                        <select class="form-control" id="city-dropdown" name="city">
                            <option value="" selected disabled hidden>Select City</option>
                        </select>
                        <div class="error" id="cityErr"></div>
                    </div>
                </div>
                Pincode: <input type="text" id="pincode" name="pincode" class="pincode" placeholder="Enter pincode" data-inputmask="'mask':'999999'" onchange="check_pincode()"></p>
                <div class="error" id="pincodeErr"></div>
            </div>
        </div>

        <!--Contact Details-->
        <h2>Contact Details</h2>

        Mobile No.: <input type="tel" id="mobile" name="mobile" class="mobile" maxlength="10" onchange="validate_mobile()" placeholder="Enter Mobile Number">&nbsp;&nbsp;&nbsp;&nbsp;
        Email-Id: <input type="email" id="email" name="email" class="email" onchange="validate_email()" placeholder="Enter Email address" maxlength="50">
        <div class="error" id="mobileErr" style="float:left; margin-left: 10px;"></div>&nbsp;&nbsp;&nbsp;&nbsp;
        <div class="error" id="emailErr" style="float:right; margin-right: 40px;"></div><br><br>
        <!--Other Details-->
        <h2>Other Details</h2>
        <div class="other">
            <p>Aadhar Card Number: <input name="aadhar" class="aadhar" id="aadhar" placeholder="xxxx xxxx xxxx" data-inputmask="'mask': '9999 9999 9999'" size="14" onchange="check_aadhar()"></p>
            <div class="error" id="aadharErr"></div>

            <!--image-->
            <p>Profile Photo: <input type="file" accept=".jpg,.png,.jpeg" id="image" name="image" value="" onchange="show(this)">
            <div class="error" id="imageErr"></div>
            <img id="output" />
        </div>
        <button type="submit" value="submit" id="submit" name="submit" class="submit">Submit </button>

    </form>
    <!-- ***********************************************JAVASCRIPT***************************************************** -->
    <script>
        /*input mask (spacing in between the numbers or used for formatting the number style)*/
        $(":input").inputmask();
        $("#aadhar").inputmask({
            "mask": "9999 9999 9999"
        });

        // Function for Priveiw Image
        var loadFile = function(event) {
            var output = document.getElementById('output'); /*function is called by id*/
            output.src = URL.createObjectURL(event.target.files[0]); /* an object is created */
            output.onload = function() {
                URL.revokeObjectURL(output.src) /*the created object is called to display image*/
            }
        };
        //   CSRF TOKEN
        // var csrf_value = '<?php echo $this->security->get_csrf_hash(); ?>';
        // console.log(csrf_value);

        // AJAX for State Dropdown
        $(document).ready(function() {
            $('#country-dropdown').change(function() {
                var country_id = $('#country-dropdown').val();
                if (country_id != '') {
                    $.ajax({
                        url: "<?php echo base_url(); ?>Register_controller/fetch_state",
                        method: "POST",
                        data: {
                            country_id: country_id
                            //   "csrf_test_name": csrf_value
                        },
                        success: function(data) {
                            // console.log(data)
                            const states = JSON.parse(data);
                            var state_option = '<option value="" selected disabled hidden>Select State</option>';
                            for (var i = 0; i < states.length; i++) {
                                state_option += "<option value='" + states[i].state_id + "'>" + states[i].state_name + "</option>"

                            }
                            $('#state-dropdown').html(state_option);
                            $('#city-dropdown').html('<option value="">Select City</option>');
                        },
                        error: function(data) {
                            console.log(error);
                        }
                    });
                } else {
                    $('#state-dropdown').html('<option value="">Select State</option>');
                    $('#city-dropdown').html('<option value="">Select City</option>');
                    return ($data);
                }
            });

            //  AJAX for City Dropdown
            $('#state-dropdown').change(function() {
                var state_id = $('#state-dropdown').val();
                if (state_id != '') {
                    $.ajax({
                        url: "<?php echo base_url(); ?>Register_controller/fetch_city",
                        method: "POST",
                        data: {
                            state_id: state_id
                            //   "csrf_test_name": csrf_value
                        },
                        success: function(data) {
                            // console.log(data)
                            const cities = JSON.parse(data);
                            var city_option = '<option value="" selected disabled hidden>Select City</option>';
                            for (var i = 0; i < cities.length; i++) {
                                city_option += "<option value='" + cities[i].city_id + "'>" + cities[i].city_name + "</option>"

                            }
                            $('#city-dropdown').html(city_option);
                        },
                        error: function(data) {
                            console.log(error);
                        }
                    });
                } else {
                    $('#city-dropdown').html('<option value="">Select City</option>');
                    return ($data);
                }
            });
        });

        // Name validations
        document.addEventListener('DOMContentLoaded', function() {

            var input = document.getElementById('name');
            input.addEventListener('keydown', function(e) {
                var input = e.target;
                var val = input.value;
                var end = input.selectionEnd;
                if (e.keyCode == 32 && (val[end - 1] == " " || val[end] == " ")) {
                    e.preventDefault();
                    return false;
                }
            });
        });

        /*address validation*/
        document.getElementById("address").addEventListener('keydown', function(e) {
            if (this.value.length === 0 && e.which === 32) e.preventDefault();
        });
        document.addEventListener('DOMContentLoaded', function() {

            var input = document.getElementById('address');
            input.addEventListener('keydown', function(e) {
                var input = e.target;
                var val = input.value;
                var end = input.selectionEnd;
                if (e.keyCode == 32 && (val[end - 1] == " " || val[end] == " ")) {
                    e.preventDefault();
                    return false;
                }
            });
        });

        // name validations
        $(function() {
            $("#name").keypress(function(e) {
                var key = e.keyCode || e.which;
                if (!((key >= 65 && key <= 90) || (key >= 97 && key <= 122) || key == 32)) {
                    $("#nameErr").html("Only Alphabets allowed.");
                    return false;
                } else {
                    $("#name").css({
                        "border": "1px solid grey"
                    });
                    $("#nameErr").text("");
                    return true;
                }
                return isValid;
            });
            $("#name").change(function(e) {
                var f_val = $("#name").val();
                if (f_val == "") {
                    $("#name").css({
                        "border": "1px solid red"
                    });
                    $("#nameErr").text(" Name Must Be Filled!");
                } else {
                    $("#name").css({
                        "border": "1px solid grey"
                    });
                    $("#nameErr").text("");
                }
            });
            $("#submit").click(function() {
                var name = $('#name').val();
                if (name == "") {
                    $("#nameErr").text("Name must be filled!");
                    $('#nameErr').focus();
                }
            });
        });
        // email validations
        function printError(elemId, hintMsg) {
            document.getElementById(elemId).innerHTML = hintMsg;
        }

        function validate_email() {
            var email = document.form.email.value;
            // Defining error variables with a default value
            var emailErr = true;
            // Validate email address
            if (email == "") {
                printError("emailErr", "Please enter your email address");
            } else {
                // Regular expression for basic email validation
                var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                if (regex.test(email) === false) {
                    printError("emailErr", "Please enter a valid email address");
                } else {
                    printError("emailErr", "");
                    emailErr = false;
                }
            }
        }
        $("#submit").click(function() {
            var email = $('#email').val();
            if (email == "") {
                $("#emailErr").text("Email Address must be filled!");
                $('#emailErr').focus();
            }
        });


        // address validations
        function check_add() {
            var add_val = $("#address").val();
            var regex = /^[a-zA-Z0-9\s'/@,.:&-]+$/;
            if (add_val == "") {
                $("#address").css({
                    "border": "1px solid red"
                });
                $("#addressErr").text("Address Must Be Filled !");
                $("#addressErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else if (regex.test(add_val) === false) {
                $("#addressErr").text(" Address Must Be Valid!");
                $("#addressErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else {
                $("#address").css({
                    "border": "1px solid grey"
                });
                $("#addressErr").text("");
                $("#addressErr").css({
                    "margin-top": "0px"
                });
            }
        }
        $("#submit").click(function() {
            var address = $('#address').val();
            if (address == "") {
                $("#addressErr").text("Address must be filled!");
                $('#addressErr').focus();
            }
        });
        // mobile validation
        function printError(elemId, hintMsg) {
            document.getElementById(elemId).innerHTML = hintMsg;
        }

        function validate_mobile() {
            var mobile = document.form.mobile.value;
            // Defining error variables with a default value
            var mobileErr = true;
            if (mobile == "") {
                printError("mobileErr", "Please enter your mobile number");
            } else {
                var regex = /^[1-9]\d{9}$/;
                if (regex.test(mobile) === false) {
                    printError("mobileErr", "Please enter a valid 10 digit mobile number");
                } else {
                    printError("mobileErr", "");
                    mobileErr = false;
                }
            }

        }
        $("#submit").click(function() {
            var email = $('#mobile').val();

            if (email == "") {
                $("#mobileErr").text("mobile must be filled!");
                $('#mobileErr').focus();
            }
        });


        // addhar validation
        function check_aadhar() {
            var adhar_val = $("#aadhar").val();
            var regex = /^\d{4}\s\d{4}\s\d{4}$/
            var r = regex.test(adhar_val);
            if (adhar_val == "") {
                $("#aadhar").css({
                    "border": "1px solid red"
                });
                $("#aadharErr").text("Aadhar Card number Must Be Filled !");
                $("#aadharErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else if (regex.test(adhar_val) === false) {
                $("#aadharErr").text("Aadhar Card number Must Be Valid!");
                $("#aadharErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else {
                $("#aadhar").css({
                    "border": "1px solid grey"
                });
                $("#aadharErr").text("");
                $("#aadharErr").css({
                    "margin-top": "0px"
                });
                // $("#submit").click(function () 
                // {
                //     if ($('#aadhar')[0].files.length === 0)
                //     {
                //         $("#aadharErr").text("Select photo!");
                //     } 
                // });    
            }
        }

        // pincode validations
        function check_pincode() {
            var pin_val = $("#pincode").val();
            var regex = /^[0-9]{6}$/
            if (pin_val == "") {
                $("#pincode").css({
                    "border": "1px solid red"
                });
                $("#pincodeErr").text("Pincode Must Be Filled !");
                $("#pincodeErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else if (regex.test(pin_val) === false) {
                $("#pincodeErr").text(" Pincode Must Be Valid!");
                $("#pincodeErr").css({
                    "margin-top": "5px",
                    "color": "red"
                });
            } else {
                $("#pincode").css({
                    "border": "1px solid grey"
                });
                $("#pincodeErr").text("");
                $("#pincodeErr").css({
                    "margin-top": "0px"
                });
            }
        }

        // Gender Validations
        $("#submit").click(function(e) {
            // validations for gender
            var gender = $("input[name='gender']:checked").val();
            if (gender) {
                $("#genderErr").text("");
            } else {
                $("#genderErr").text("Select gender!");
                e.preventDefault();
            }

            /* validation for marital status */
            var Maritial_status = $("input[name='Maritial_status']:checked").val();
            if (Maritial_status) {
                $("#statusErr").text("");
            } else {
                $("#statusErr").text("Select marital status!");
                e.preventDefault();
            }
        });

        /* validation - on click gender radio button */
        $('input[type=radio][name=gender]').click(function() {
            if (this.value == 'male') {
                $("#genderErr").text(" ");
            } else if (this.value == 'female') {
                $("#genderErr").text(" ");
            } else if (this.value == 'other') {
                $("#genderErr").text(" ");
            }
        });
        /* validation - on click maritalStatus radio button */
        $('input[type=radio][name=Maritial_status]').click(function() {
            if (this.value == 'Single') {
                $("#statusErr").text(" ");
            } else if (this.value == 'Married') {
                $("#statusErr").text(" ");
            } else if (this.value == 'Divorced') {
                $("#statusErr").text(" ");
            }
        });

        // image validations
        function show(input) {

            var validExtensions = ['jpg', 'png', 'jpeg']; //array of valid extensions
            var fileName = input.files[0].name;
            // console.log(fileName);
            var fileNameExt = fileName.substr(fileName.lastIndexOf('.') + 1);

            if ($.inArray(fileNameExt, validExtensions) == -1) {
                input.type = ''
                input.type = 'file'
                $('#output').attr('src', "");
                printError("imageErr", "Only these file types are accepted : " + validExtensions.join(', '));
            } else {
                if (input.files && input.files[0]) {
                    var filerdr = new FileReader();
                    filerdr.onload = function(e) {
                        $('#output').attr('src', e.target.result);
                    }
                    filerdr.readAsDataURL(input.files[0]);
                    printError("imageErr", "")
                }
            }
        }
        /*validation for photo */
        $("#submit").click(function() {
            if ($('#image')[0].files.length === 0) {
                $("#imageErr").text("Select photo!");
            }
        });

        //blood_group validations
        $(function() {
            $("#submit").click(function() {
                var blood_group = $('#blood_group').val();
                if (blood_group == 0) {
                    $("#blooderr").text("Please select blood group!");
                    $('#blood_group').focus();
                }
            });
            $('#blood_group').change(function() {
                $("#blooderr").text("");
            });
        });
        // date validations
        $(function() {
            $("#submit").click(function() {
                var dob = $('#dob').val();
                if (dob == 0) {
                    $("#dobErr").text("Please select your Birth-Date!");
                    $('#dob').focus();
                }
            });
            $('#dob').change(function() {
                $("#dobErr").text("");
            });
        });

        // country-state-city validations
        $(function() {
            $("#submit").click(function() {
                var country = $('#country-dropdown').val();
                var state = $('#state-dropdown').val();
                var city = $('#city-dropdown').val();
                if (country == null) {
                    $("#countryErr").text("Please select country!");
                    $('#country-dropdown').focus();
                } else if (state == null) {
                    $("#stateErr").text("Please select state!");
                    $('#state-dropdown').focus();
                } else if (city == null) {
                    $("#cityErr").text("Please select city!");
                    $('#city-dropdown').focus();
                } else {
                    $("#countryErr").text("");
                    $("#stateErr").text("");
                    $("#cityErr").text("");
                }
            });
            $('#country-dropdown').change(function() {
                $("#countryErr").text("");
            });
            $('#state-dropdown').change(function() {
                $("#stateErr").text("");
            });
            $('#city-dropdown').change(function() {
                $("#cityErr").text("");
            });
        });

        var PHOTO_PATH = '';
        $(function() {
            $('#form').on("submit", function(e) {
                // var file = $('#image')[0].files; //fetch file
                // console.log(file);
                e.preventDefault();
                var formData = new FormData(this);
                // formData.append('csrf_test_name',  csrf_value );
                // formData.append('files[]', file[0]); //append file to formData object
                // console.log(formData);
                $.ajax({
                    url: "<?php echo base_url(); ?>Register_controller/savedata",
                    type: "POST",
                    data: formData,
                    processData: false, //prevent jQuery from converting your FormData into a string
                    contentType: false, //jQuery does not add a Content-Type header for you
                    success: function(msg) {
                        // alert(msg)
                        var res = JSON.parse(msg)
                        console.log(res[0].res);
                        if (res[0].res == 'user') {
                            // alert('user already register ');
                            swal({
                                    title: "ALERT !!",
                                    text: "User is already Register !!",
                                    type: "warning",
                                    confirmButtonClass: "btn-warning",
                                    confirmButtonText: "Try Again!",
                                    // closeOnConfirm: false
                                },
                                function() {
                                    location.reload();

                                });

                        } else {
                            swal("Good job!", "Record Inserted Succesfully", "success")
                            location.href = '<?php echo base_url(); ?>Register_controller/retrieve'
                        }
                    }
                });
            });
        });
    </script>

</body>

</html>